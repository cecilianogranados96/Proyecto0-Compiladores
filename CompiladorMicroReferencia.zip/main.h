#include <stdio.h>
#define true 1
// 
// declaracion de variables globales con extern
//

extern FILE *file_in;
extern FILE *file_out;
