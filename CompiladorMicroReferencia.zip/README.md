# Compiladores_e_Interpretes
Archivos de las tareas programadas del curso Compiladores e Intérpretes

#Integrantes
Martine Deiner
Vargas Jose Pablo

#Referencias
Capitulo 2 - Crafting a Compiler with C

#Ejecutando
para compilar utilizar:
	make
para ejecutar utilizar:
	./prog sourceMicro outputMicro
